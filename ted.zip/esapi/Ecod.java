package com.other.universal.alone.esapi;


public class Ecod {

    public static void main(String[] args) {
        DefaultEncoder.canonicalize("asdas");
    }

}
