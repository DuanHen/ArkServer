package com.other.universal.alone.esapi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DefaultEncoder {

    private static List codecs = new ArrayList();

    private HTMLEntityCodec htmlCodec = new HTMLEntityCodec();

    private PercentCodec percentCodec = new PercentCodec();

    public DefaultEncoder( List<String> codecNames ) {
        for ( String clazz : codecNames ) {
            try {
                if ( clazz.indexOf( '.' ) == -1 ) clazz = "com.other.universal.alone.esapi." + clazz;
                codecs.add( Class.forName( clazz ).newInstance() );
            } catch ( Exception e ) {
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    public static String canonicalize(String input) {
        if (input == null) {
            return null;
        }


        List<String> codecNames = new ArrayList<>();
        codecNames.add("HTMLEntityCodec");
        new DefaultEncoder(codecNames);
        // Issue 231 - These are reverse boolean logic in the Encoder interface, so we need to invert these values - CS
        return canonicalize(input,
                false,
                false);
    }

    /**
     * {@inheritDoc}
     */
    public static String canonicalize(String input, boolean restrictMultiple, boolean restrictMixed) {
        if (input == null) {
            return null;
        }

        String working = input;
        Codec codecFound = null;
        int mixedCount = 1;
        int foundCount = 0;
        boolean clean = false;
        while (!clean) {
            clean = true;

            // try each codec and keep track of which ones work
            Iterator i = codecs.iterator();
            while (i.hasNext()) {
                Codec codec = (Codec) i.next();
                String old = working;
                working = codec.decode(working);
                if (!old.equals(working)) {
                    if (codecFound != null && codecFound != codec) {
                        mixedCount++;
                    }
                    codecFound = codec;
                    if (clean) {
                        foundCount++;
                    }
                    clean = false;
                }
            }
        }

        // do strict tests and handle if any mixed, multiple, nested encoding were found
        if (foundCount >= 2 && mixedCount > 1) {
            if (restrictMultiple || restrictMixed) {
            } else if (foundCount >= 2) {
                if (restrictMultiple) {
                }
            } else if (mixedCount > 1) {
                if (restrictMixed) {
                }
            }

        }
        return working;
    }
}